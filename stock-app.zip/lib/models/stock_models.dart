class StockQuote {
  final String symbol;
  final double currentPrice;
  final double change;
  final double changePercent;
  final double highPrice;
  final double lowPrice;
  final double openPrice;
  final double previousClose;
  final DateTime timestamp;

  StockQuote({
    required this.symbol,
    required this.currentPrice,
    required this.change,
    required this.changePercent,
    required this.highPrice,
    required this.lowPrice,
    required this.openPrice,
    required this.previousClose,
    required this.timestamp,
  });

  factory StockQuote.fromJson(Map<String, dynamic> json, String symbol) {
    final double current = (json['c'] as num?)?.toDouble() ?? 0.0;
    final double high = (json['h'] as num?)?.toDouble() ?? 0.0;
    final double low = (json['l'] as num?)?.toDouble() ?? 0.0;
    final double open = (json['o'] as num?)?.toDouble() ?? 0.0;
    final double previousClose = (json['pc'] as num?)?.toDouble() ?? 0.0;
    final double change = (json['d'] as num?)?.toDouble() ?? 0.0;
    final double changePercent = (json['dp'] as num?)?.toDouble() ?? 0.0;

    return StockQuote(
      symbol: symbol,
      currentPrice: current,
      change: change,
      changePercent: changePercent,
      highPrice: high,
      lowPrice: low,
      openPrice: open,
      previousClose: previousClose,
      timestamp: DateTime.now(),
    );
  }

  bool get isPositive => change >= 0;
}

class CandleData {
  final DateTime timestamp;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  CandleData({
    required this.timestamp,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory CandleData.fromJson(Map<String, dynamic> json, int index) {
    final List<dynamic> timestamps = json['t'] as List<dynamic>;
    final List<dynamic> opens = json['o'] as List<dynamic>;
    final List<dynamic> highs = json['h'] as List<dynamic>;
    final List<dynamic> lows = json['l'] as List<dynamic>;
    final List<dynamic> closes = json['c'] as List<dynamic>;
    final List<dynamic> volumes = json['v'] as List<dynamic>;

    return CandleData(
      timestamp: DateTime.fromMillisecondsSinceEpoch(
        (timestamps[index] as int) * 1000,
      ),
      open: (opens[index] as num).toDouble(),
      high: (highs[index] as num).toDouble(),
      low: (lows[index] as num).toDouble(),
      close: (closes[index] as num).toDouble(),
      volume: (volumes[index] as num).toInt(),
    );
  }
}

class StockSymbol {
  final String symbol;
  final String description;
  final String displaySymbol;
  final String type;

  StockSymbol({
    required this.symbol,
    required this.description,
    required this.displaySymbol,
    required this.type,
  });

  factory StockSymbol.fromJson(Map<String, dynamic> json) {
    return StockSymbol(
      symbol: json['symbol'] as String? ?? '',
      description: json['description'] as String? ?? '',
      displaySymbol: json['displaySymbol'] as String? ?? '',
      type: json['type'] as String? ?? '',
    );
  }
}
