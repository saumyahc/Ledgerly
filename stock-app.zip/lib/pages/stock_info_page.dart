import 'dart:async';
import 'package:flutter/material.dart';
import '../constants.dart';
import '../models/stock_models.dart';
import '../services/stock_service.dart';
import '../widgets/stock_chart.dart';

class StockInfoPage extends StatefulWidget {
  const StockInfoPage({super.key});

  @override
  State<StockInfoPage> createState() => _StockInfoPageState();
}

class _StockInfoPageState extends State<StockInfoPage> {
  final StockService _stockService = StockService();
  final TextEditingController _searchController = TextEditingController();
  
  List<String> _watchlist = StockService.popularSymbols;
  Map<String, StockQuote> _quotes = {};
  Map<String, List<CandleData>> _chartData = {};
  String? _selectedSymbol;
  bool _isLoading = true;
  String? _error;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _initializeData();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initializeData() async {
    if (FinnhubConstants.apiKey == 'YOUR_FINNHUB_API_KEY_HERE') {
      setState(() {
        _error = 'Please set your Finnhub API key in constants.dart';
        _isLoading = false;
      });
      return;
    }

    await _loadQuotes();
    if (_watchlist.isNotEmpty) {
      _selectedSymbol = _watchlist.first;
      await _loadChartData(_selectedSymbol!);
    }
  }

  Future<void> _loadQuotes() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final Map<String, StockQuote> newQuotes = {};
      
      // Load quotes in batches to avoid rate limiting
      for (int i = 0; i < _watchlist.length; i += 3) {
        final batch = _watchlist.skip(i).take(3);
        final futures = batch.map((symbol) => _stockService.getQuote(symbol));
        final results = await Future.wait(futures);
        
        for (int j = 0; j < results.length; j++) {
          final quote = results[j];
          if (quote != null) {
            newQuotes[batch.elementAt(j)] = quote;
          }
        }
        
        // Small delay between batches
        if (i + 3 < _watchlist.length) {
          await Future.delayed(const Duration(milliseconds: 200));
        }
      }

      setState(() {
        _quotes = newQuotes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load stock data: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadChartData(String symbol) async {
    try {
      final candleData = await _stockService.getCandleData(symbol);
      setState(() {
        _chartData[symbol] = candleData;
      });
    } catch (e) {
      print('Failed to load chart data for $symbol: $e');
    }
  }

  void _startAutoRefresh() {
    _refreshTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted && !_isLoading) {
        _loadQuotes();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Stock Market'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _loadQuotes,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Chart Section
          if (_selectedSymbol != null) _buildChartSection(),
          
          // Stock List
          Expanded(
            child: _buildStockList(),
          ),
        ],
      ),
    );
  }

  Widget _buildChartSection() {
    final quote = _quotes[_selectedSymbol];
    final chartData = _chartData[_selectedSymbol] ?? [];
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _selectedSymbol!,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (quote != null) ...[
                    Text(
                      '\$${quote.currentPrice.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: quote.isPositive
                            ? AppColors.success.withOpacity(0.1)
                            : AppColors.error.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${quote.isPositive ? '+' : ''}${quote.change.toStringAsFixed(2)} (${quote.changePercent.toStringAsFixed(2)}%)',
                        style: TextStyle(
                          color: quote.isPositive
                              ? AppColors.success
                              : AppColors.error,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              // Time period selector
              Row(
                children: ['1D', '1W', '1M', '3M']
                    .map((period) => Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: TextButton(
                            onPressed: () => _loadChartData(_selectedSymbol!),
                            child: Text(period),
                          ),
                        ))
                    .toList(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          StockChart(
            candleData: chartData,
            symbol: _selectedSymbol!,
            isPositive: quote?.isPositive ?? true,
          ),
        ],
      ),
    );
  }

  Widget _buildStockList() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading stock data...'),
          ],
        ),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: AppColors.error,
            ),
            const SizedBox(height: 16),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadQuotes,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadQuotes,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _watchlist.length,
        itemBuilder: (context, index) {
          final symbol = _watchlist[index];
          final quote = _quotes[symbol];
          
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.primary,
                child: Text(
                  symbol.substring(0, 1),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                symbol,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(_getCompanyName(symbol)),
              trailing: quote != null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '\$${quote.currentPrice.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          '${quote.isPositive ? '+' : ''}${quote.change.toStringAsFixed(2)}',
                          style: TextStyle(
                            color: quote.isPositive
                                ? AppColors.success
                                : AppColors.error,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
              onTap: () {
                setState(() {
                  _selectedSymbol = symbol;
                });
                _loadChartData(symbol);
              },
              selected: _selectedSymbol == symbol,
              selectedTileColor: AppColors.primary.withOpacity(0.1),
            ),
          );
        },
      ),
    );
  }

  String _getCompanyName(String symbol) {
    const Map<String, String> companies = {
      'AAPL': 'Apple Inc.',
      'GOOGL': 'Alphabet Inc.',
      'MSFT': 'Microsoft Corporation',
      'AMZN': 'Amazon.com Inc.',
      'TSLA': 'Tesla Inc.',
      'META': 'Meta Platforms Inc.',
      'NVDA': 'NVIDIA Corporation',
      'NFLX': 'Netflix Inc.',
      'AMD': 'Advanced Micro Devices',
      'INTC': 'Intel Corporation',
    };
    return companies[symbol] ?? '$symbol Inc.';
  }
}
