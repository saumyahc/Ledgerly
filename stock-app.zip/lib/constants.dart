class FinnhubConstants {
  // Replace with your actual Finnhub API key from https://finnhub.io/
  static const String apiKey = 'YOUR_FINNHUB_API_KEY_HERE';
  
  static const String baseUrl = 'https://finnhub.io/api/v1';
  
  static String quoteUrl(String symbol) {
    return '$baseUrl/quote?symbol=$symbol&token=$apiKey';
  }
  
  static String symbolsUrl(String exchange) {
    return '$baseUrl/stock/symbol?exchange=$exchange&token=$apiKey';
  }
  
  static String candleUrl(String symbol, String resolution, int from, int to) {
    return '$baseUrl/stock/candle?symbol=$symbol&resolution=$resolution&from=$from&to=$to&token=$apiKey';
  }
  
  static String companyProfileUrl(String symbol) {
    return '$baseUrl/stock/profile2?symbol=$symbol&token=$apiKey';
  }
}

class AppColors {
  static const primary = Color(0xFF2196F3);
  static const accent = Color(0xFF4CAF50);
  static const background = Color(0xFFF5F5F5);
  static const surface = Color(0xFFFFFFFF);
  static const error = Color(0xFFE53E3E);
  static const success = Color(0xFF38A169);
}
