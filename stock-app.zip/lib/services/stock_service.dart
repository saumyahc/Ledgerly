import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants.dart';
import '../models/stock_models.dart';

class StockService {
  static const Duration _timeout = Duration(seconds: 10);
  static const Duration _cacheExpiry = Duration(minutes: 1);
  
  final Map<String, StockQuote> _quoteCache = {};
  final Map<String, DateTime> _cacheTimestamps = {};
  final Map<String, List<CandleData>> _candleCache = {};

  // Popular stock symbols for demo
  static const List<String> popularSymbols = [
    'AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 
    'META', 'NVDA', 'NFLX', 'AMD', 'INTC'
  ];

  Future<StockQuote?> getQuote(String symbol) async {
    try {
      // Check cache first
      if (_isQuoteCached(symbol)) {
        return _quoteCache[symbol];
      }

      final uri = Uri.parse(FinnhubConstants.quoteUrl(symbol));
      final response = await http.get(uri).timeout(_timeout);

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        
        // Check if response has valid data
        if (data['c'] != null && data['c'] != 0) {
          final quote = StockQuote.fromJson(data, symbol);
          _cacheQuote(symbol, quote);
          return quote;
        }
      }
      
      print('Failed to fetch quote for $symbol: ${response.statusCode}');
      return null;
    } catch (e) {
      print('Error fetching quote for $symbol: $e');
      return null;
    }
  }

  Future<List<CandleData>> getCandleData(
    String symbol, {
    String resolution = 'D',
    int? daysBack = 30,
  }) async {
    try {
      final cacheKey = '${symbol}_${resolution}_$daysBack';
      
      // Check cache
      if (_candleCache.containsKey(cacheKey)) {
        final cached = _candleCache[cacheKey]!;
        if (cached.isNotEmpty) return cached;
      }

      final now = DateTime.now();
      final from = now.subtract(Duration(days: daysBack ?? 30));
      
      final uri = Uri.parse(FinnhubConstants.candleUrl(
        symbol,
        resolution,
        from.millisecondsSinceEpoch ~/ 1000,
        now.millisecondsSinceEpoch ~/ 1000,
      ));

      final response = await http.get(uri).timeout(_timeout);

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        
        if (data['s'] == 'ok' && data['t'] != null) {
          final List<dynamic> timestamps = data['t'] as List<dynamic>;
          final List<CandleData> candles = [];
          
          for (int i = 0; i < timestamps.length; i++) {
            candles.add(CandleData.fromJson(data, i));
          }
          
          _candleCache[cacheKey] = candles;
          return candles;
        }
      }
      
      print('Failed to fetch candle data for $symbol: ${response.statusCode}');
      return [];
    } catch (e) {
      print('Error fetching candle data for $symbol: $e');
      return [];
    }
  }

  Future<List<StockSymbol>> searchSymbols(String query) async {
    try {
      // For demo purposes, filter from popular symbols
      // In production, you'd use Finnhub's symbol search API
      final filtered = popularSymbols
          .where((symbol) => 
              symbol.toLowerCase().contains(query.toLowerCase()))
          .map((symbol) => StockSymbol(
                symbol: symbol,
                description: _getCompanyName(symbol),
                displaySymbol: symbol,
                type: 'Common Stock',
              ))
          .toList();
      
      return filtered;
    } catch (e) {
      print('Error searching symbols: $e');
      return [];
    }
  }

  String _getCompanyName(String symbol) {
    const Map<String, String> companies = {
      'AAPL': 'Apple Inc.',
      'GOOGL': 'Alphabet Inc.',
      'MSFT': 'Microsoft Corporation',
      'AMZN': 'Amazon.com Inc.',
      'TSLA': 'Tesla Inc.',
      'META': 'Meta Platforms Inc.',
      'NVDA': 'NVIDIA Corporation',
      'NFLX': 'Netflix Inc.',
      'AMD': 'Advanced Micro Devices',
      'INTC': 'Intel Corporation',
    };
    return companies[symbol] ?? '$symbol Inc.';
  }

  bool _isQuoteCached(String symbol) {
    if (!_quoteCache.containsKey(symbol) || !_cacheTimestamps.containsKey(symbol)) {
      return false;
    }
    
    final timestamp = _cacheTimestamps[symbol]!;
    return DateTime.now().difference(timestamp) < _cacheExpiry;
  }

  void _cacheQuote(String symbol, StockQuote quote) {
    _quoteCache[symbol] = quote;
    _cacheTimestamps[symbol] = DateTime.now();
  }

  void clearCache() {
    _quoteCache.clear();
    _cacheTimestamps.clear();
    _candleCache.clear();
  }
}
