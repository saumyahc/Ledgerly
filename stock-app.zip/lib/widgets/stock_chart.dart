import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/stock_models.dart';
import '../constants.dart';

class StockChart extends StatelessWidget {
  final List<CandleData> candleData;
  final String symbol;
  final bool isPositive;

  const StockChart({
    super.key,
    required this.candleData,
    required this.symbol,
    required this.isPositive,
  });

  @override
  Widget build(BuildContext context) {
    if (candleData.isEmpty) {
      return Container(
        height: 200,
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Container(
      height: 200,
      padding: const EdgeInsets.all(16),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: _calculateInterval(),
            getDrawingHorizontalLine: (value) {
              return FlLine(
                color: Colors.grey.withOpacity(0.3),
                strokeWidth: 1,
              );
            },
          ),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                interval: candleData.length / 4,
                getTitlesWidget: (double value, TitleMeta meta) {
                  final index = value.toInt();
                  if (index >= 0 && index < candleData.length) {
                    final date = candleData[index].timestamp;
                    return SideTitleWidget(
                      axisSide: meta.axisSide,
                      child: Text(
                        '${date.month}/${date.day}',
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 10,
                        ),
                      ),
                    );
                  }
                  return const Text('');
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: _calculateInterval(),
                reservedSize: 60,
                getTitlesWidget: (double value, TitleMeta meta) {
                  return Text(
                    '\$${value.toStringAsFixed(0)}',
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                    ),
                  );
                },
              ),
            ),
          ),
          borderData: FlBorderData(
            show: true,
            border: Border.all(color: Colors.grey.withOpacity(0.3)),
          ),
          minX: 0,
          maxX: candleData.length.toDouble() - 1,
          minY: _getMinPrice() * 0.995,
          maxY: _getMaxPrice() * 1.005,
          lineBarsData: [
            LineChartBarData(
              spots: _generateSpots(),
              isCurved: true,
              gradient: LinearGradient(
                colors: isPositive
                    ? [AppColors.success, AppColors.success.withOpacity(0.3)]
                    : [AppColors.error, AppColors.error.withOpacity(0.3)],
              ),
              barWidth: 3,
              isStrokeCapRound: true,
              dotData: FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  colors: isPositive
                      ? [
                          AppColors.success.withOpacity(0.3),
                          AppColors.success.withOpacity(0.1),
                        ]
                      : [
                          AppColors.error.withOpacity(0.3),
                          AppColors.error.withOpacity(0.1),
                        ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<FlSpot> _generateSpots() {
    return candleData.asMap().entries.map((entry) {
      return FlSpot(entry.key.toDouble(), entry.value.close);
    }).toList();
  }

  double _getMinPrice() {
    return candleData.map((e) => e.low).reduce((a, b) => a < b ? a : b);
  }

  double _getMaxPrice() {
    return candleData.map((e) => e.high).reduce((a, b) => a > b ? a : b);
  }

  double _calculateInterval() {
    final range = _getMaxPrice() - _getMinPrice();
    return range / 5; // 5 horizontal grid lines
  }
}
